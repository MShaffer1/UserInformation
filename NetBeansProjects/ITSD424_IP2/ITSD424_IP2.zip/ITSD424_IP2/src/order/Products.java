
package order;

/**
 *
 * @author Peanu
 */
public class Products {
  
    static class sandType{
        
        String name;
        double price;
        
    }
    static class breadType {
        
        String name;
        double price;
      
    }
    static class size {
        
        String name;
        double price;
      
    }
    static class sideItem {
        
        String name;
        double price;
      
    }
    static class drink {
        
        String name;
        double price;
      
    }
}
