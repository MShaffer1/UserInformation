
package Vector;

import java.util.ArrayList;

/**
 *
 * @author Peanu
 */
public class Products extends Form {

    private String sandwichName;
    private String breadType;
    private String sideItem;
    private String drinkName;
    private double price;
    
    public String getSandwichName() {
        return sandwichName;
    }

    public void setSandwichName(String sandwichName) {
        this.sandwichName = sandwichName;
    }

    public String getBreadType() {
        return breadType;
    }

    public void setBreadType(String breadType) {
        this.breadType = breadType;
    }

    public String getSideItem() {
        return sideItem;
    }

    public void setSideItem(String sideItem) {
        this.sideItem = sideItem;
    }

    public String getDrinkName() {
        return drinkName;
    }

    public void setDrinkName(String drinkName) {
        this.drinkName = drinkName;
    }

    public String getName() {
        return sandwichName;
    }

    public void setName(String name) {
        this.sandwichName = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
}