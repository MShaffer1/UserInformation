
package Vector;

import java.awt.BorderLayout;
import java.awt.HeadlessException;
import java.util.Vector;
import javax.swing.*;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * @author Michelle
 */
public class Form {
       
    public static void main(String[] args) {
        
        promptUser();

        //JOptionPane to asks for the user's full name
    
        //create java frame and components
        JFrame frame = new JFrame();          
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Sub Shop");

        //add Button
        JButton button1 = new JButton("Submit"); //name of 1st button
        JButton button2 = new JButton("Clear"); //name of 2nd button
        JPanel panel1 = new JPanel(); //create panel
        panel1.add(button1); //add button to panel
        panel1.setSize(600,600);//panel size
        JPanel panel2 = new JPanel();//creates a 2nd panel
        panel2.setSize(199,99);//2nd panel size
        panel2.add(button2, BorderLayout.SOUTH);//places button in specified position    
        frame.add(panel1, BorderLayout.SOUTH);//specifies panel position
        frame.add(panel2, BorderLayout.EAST);//specifies panel position
        JTextArea userSelected = new JTextArea();//creates text area to display user's selection
        panel2.add(userSelected);//adds the text area to the panel
        userSelected.setFocusable(false);//disables user from inputting their own text in text area
        
        //customized text area with colors, row & column count, and size 
        userSelected.setBackground(new java.awt.Color(204, 255, 204));
        userSelected.setColumns(15);
        userSelected.setFont(new java.awt.Font("Arial Black", 0, 14)); 
        userSelected.setLineWrap(true);
        userSelected.setRows(5);
        userSelected.setFocusable(false);
             
             
        //create vector f using the Sandwich class with initial capacity of 4       
        Vector <Sandwich> f = new Vector <Sandwich>(4);
        
        
        //creates sandwich objects
        Sandwich sandwich1 = new Sandwich("Italian", 5.99);
        Sandwich sandwich2= new Sandwich("BLT", 4.99);
        Sandwich sandwich3 = new Sandwich("Ham & Swiss", 4.99);
        Sandwich sandwich4 = new Sandwich("Veggie", 3.99);
                   
        //adds elements from Sandwich class to the vector
        f.add(sandwich1);
        f.add(sandwich2);
        f.add(sandwich3);
        f.add(sandwich4);           
        
        
        
        //creates JList to display vector elements
        final JList <Sandwich> list = new JList<Sandwich>(f);         
        frame.add(new JScrollPane(list));
         list.setSelectionMode(
                    ListSelectionModel.MULTIPLE_INTERVAL_SELECTION); 
                                   
         //adds action listener to the list
         list.addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(ListSelectionEvent evt) {
        listValueChanged(evt);
      }
           
      //uses action listener to append selected items to textArea(userSelected)
            private void listValueChanged(ListSelectionEvent evt) {
                 if (!list.getValueIsAdjusting()) {
      userSelected.append(list.getSelectedValue().toString()+"\r\n");
    }

         }
    });         
        //adds button2 (Clear) function to clear the list                                                                       
            button2.addActionListener(new ActionListener() {            
            @Override
           public void actionPerformed(java.awt.event.ActionEvent ev){   
            userSelected.setText(null); 
     
            }   
        });  
            //adds button1 (Submit) function to display message and close program
            //also need this button to add the prices together to display with the message
           button1.addActionListener(new ActionListener() {            
            @Override
           public void actionPerformed(java.awt.event.ActionEvent ev){ 
             double var;  
         String selected = userSelected.getText().toString();
         String intValue = selected.replaceAll("[^0-9.]" , "");
         //double total = selected + intValue;   //tested code but causing errors
         //var  = Double.parseDouble(intValue);    //tested code but causing errors     
         String total = intValue;
         //need to calculate total here, but not sure how 
         JOptionPane.showMessageDialog(null,"Your total is: "  + total);
                 
        JOptionPane.showMessageDialog(null, "Your Order has been submitted!" + "\n" +  "Thank you for your business!", "Order Processed", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0); 
                                 
            }   
        });  
           //sets frame size and visibility  must be at the end of code to work.
        frame.setSize(500, 400);
         frame.setVisible(true); 
         
       
       
 }  
     

    private static String promptForName() {
        String userName = JOptionPane.showInputDialog("Please Enter Your Full Name.");
       
       if (userName.length() <=1) {
          return null; 
       } else {
         return userName;
       }
    }

    private static void promptUser() {
        String userName = promptForName();
        
         //Adds multiple text fields to a JOptionPane
        JTextField streetAddress = new JTextField();
        JTextField city = new JTextField();
        JTextField state = new JTextField();
        JTextField zip = new JTextField();
        JTextField phone = new JTextField();
       
        //Create array of objects to fill the JTextFields created above
        Object[] fields = {
            
           //Displayed text + empty field to take user input
           "Street Address", streetAddress,
           "City", city,
           "State", state,
           "Zip", zip,
            "Phone", phone
        };
        
      try {  
        do {
                
               
            if (userName == null || userName.trim().isEmpty()){
                JOptionPane.showMessageDialog(null, "Cannot Be Left Blank", "Error", JOptionPane.ERROR_MESSAGE);
                JOptionPane.showInputDialog("Please Enter Your Full Name.");
            }
            else {
                 JOptionPane.showConfirmDialog(null, fields, "Please Enter Your Information", JOptionPane.OK_CANCEL_OPTION);
                 JOptionPane.showMessageDialog(null,"Welcome to the Sub Shop " + userName + "!"); 
            }
        
 } while (userName.trim().isEmpty()&& userName == null);
      }catch (NullPointerException e){
          
          JOptionPane.showConfirmDialog(null, fields, "Please Enter Your Information", JOptionPane.OK_CANCEL_OPTION);
          JOptionPane.showMessageDialog(null,"Welcome to the Sub Shop " + userName + "!"); 
      }  
    }
   
}

    
 
       
   
    
     
 
 
     
   
