
package Vector;
/**
 * @author Michelle
 */
public class Sandwich extends Form {
    
    @Override
public String toString() {
    return name + " " + price;       
}

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }   
    private String name;
    private double price;          
    Sandwich() {              
    }             
    public static void main (String args[]){                  
    }             
        public Sandwich(String name, double price){       
            this.name = name;
            this.price = price;           
        }           
}
