
package ITSD322_u4_ip_One;

import java.util.Scanner;

/**
 *
 * @author Michelle
 */

public class PreDefMessages extends Billboard {
    
    public static void welcomeMessage() {
    
    {
       Scanner sc = new Scanner (System.in); 
        
        String welcomeMessage;
        System.out.println("Welcome");
        welcomeMessage = ("welcome");
              
        System.out.println("||---------------------------------------||");
        System.out.println("||                                       ||");
        System.out.println("||              Hello and                ||");
        System.out.println("||        " + welcomeMessage +"          ||");        
        System.out.println("||                                       ||");
        System.out.println("||---------------------------------------|\n");
    
}
    }
    
public static void inputText( )
{
Scanner sc = new Scanner (System.in);

String inputMessage;
System.out.println("How are You? (Please Enter your message)\n");
inputMessage = sc.nextLine();//use substring here
//System.out.println(inputMessage.substring(0));

        System.out.println("||---------------------------------------||");
        System.out.println("||                                       ||");
        System.out.println("||            How are You?               ||");       
        System.out.println("||        " + inputMessage + "           ||");        
        System.out.println("||                                       ||");
        System.out.println("||---------------------------------------||\n");


}

public static void ExitMessage ( )
{
    
    
        System.out.println("||---------------------------------------||");
        System.out.println("||                                       ||");
        System.out.println("||   The Java Billboard will now         ||");
        System.out.println("||                 Exit!                 ||");
        System.out.println("||                                       ||");
        System.out.println("||---------------------------------------||\n");

}      
}