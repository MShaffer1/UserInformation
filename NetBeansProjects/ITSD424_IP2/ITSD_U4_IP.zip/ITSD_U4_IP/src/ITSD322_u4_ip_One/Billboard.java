
package ITSD322_u4_ip_One;

/**
 *
 * @author Michelle
 */
public class Billboard {
    public void displayInfo()
 {
 System.out.println(" The virtual function to messages.");
 }
 
}
 
 

     

