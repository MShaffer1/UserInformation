
package ITSD322_u4_ip_One;

import static ITSD322_u4_ip_One.PreDefMessages.ExitMessage; //imports the method for Exit Message
import static ITSD322_u4_ip_One.PreDefMessages.inputText;//imports the method for text input
import static ITSD322_u4_ip_One.PreDefMessages.welcomeMessage;//imports the method for welcomeMessage
import java.util.Scanner; //keyboard scanner for input

/**
 * @author Michelle
 */
public class Billboard_Main { //Main package/program
    
    public static void main(String[] args) {
               
{
    Scanner scan = new Scanner (System.in);
    
        //declaration of integer variable
        int input;
        //This is the predefined messages menu and will loop until the user enters
        //the number "3".
        do{
             System.out.println("|---------------------------------------|");
        System.out.println("|                                       |");
        System.out.println("|   Select one of the options below     |");
        System.out.println("|     1.  Hello                         |");
        System.out.println("|     2.  How are you?                  |");
        System.out.println("|     3.  Goodbye (Exit)                |");
        System.out.println("|                                       |");
        System.out.println("|---------------------------------------|\n");
        input = scan.nextInt();
                                   
     if (input == 1) //Choice 1 of user
     {
            System.out.println();
            welcomeMessage(); //calls the method welcomeMessage from class source file
            
        
     }
        else if (input == 2)//Choice 2 of user
        {
            System.out.println();
            inputText(); //calls the method inputText from class source file
                        //user will be able to input a response to "How are You?"
            
        }
        else
        {
            System.out.println();
            ExitMessage ();//calls the method ExitMessage from class source file
                        
        }
     }
     while (input !=3);//Choice 3 of user
        }              //and will exit the program
        
     }
}
    
    
    
    
       

            

        
  
    

